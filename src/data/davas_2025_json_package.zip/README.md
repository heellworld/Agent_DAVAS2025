# Danang Venture and Angel Summit 2025 - RAG-Optimized JSON

## Overview
This repository contains JSON files optimized for Retrieval Augmented Generation (RAG) systems, containing information about the Danang Venture and Angel Summit 2025 (DAVAS 2025) event.

## Files
- `davas_2025_vi.json`: Vietnamese version of the event information
- `davas_2025_en.json`: English version with translated content
- `davas_2025_rag_optimized.json`: Enhanced version with RAG optimization features
- `davas_2025_rag_final.json`: Final version with all fixes applied
- `davas_2025_combined.json`: Combined file with metadata and all content

## JSON Structure
Each object in the JSON files follows this structure:

```json
{
  "id": "unique_identifier",
  "type": "object_type",
  "title_vi": "Vietnamese title",
  "title_en": "English title",
  "content_vi": "Vietnamese content",
  "content_en": "English content",
  "date": "event_date",
  "location": "event_location",
  "tags": ["tag1", "tag2", "..."],
  "source": "information_source",
  "language": "vi/en/both",
  "embeddings_context": "combined text for vector embedding",
  "related_terms": {
    "term1": ["synonym1", "synonym2"],
    "term2": ["synonym3", "synonym4"]
  },
  "chunking_info": {
    "type": "object_type",
    "id": "object_id",
    "language": "language",
    "chunk_size_recommendation": "medium/large"
  }
}
```

## RAG Optimization Features
1. **Expanded Tags**: Tags are expanded with synonyms in both Vietnamese and English
2. **Embeddings Context**: Combined text for better vector embedding
3. **Related Terms**: Synonyms and related terms for better query matching
4. **Chunking Info**: Information for optimal text chunking in RAG systems

## Usage in RAG Systems
1. **Vector Embedding**: Use the `embeddings_context` field for creating vector embeddings
2. **Query Expansion**: Use the `related_terms` field for query expansion
3. **Chunking**: Use the `chunking_info` field for optimal text chunking
4. **Bilingual Support**: Both Vietnamese and English content available for all objects

## Object Types
- event: Event overview information
- objective: Event objectives
- scale: Event scale and scope
- highlight: Highlighted activities
- speaker: Speaker and expert information
- agenda: Event schedule and timeline
- partner: Partner and sponsor information

## Example Usage
```python
import json
from sentence_transformers import SentenceTransformer

# Load the JSON data
with open('davas_2025_rag_final.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Create embeddings using a sentence transformer model
model = SentenceTransformer('all-MiniLM-L6-v2')
for item in data:
    item['embedding'] = model.encode(item['embeddings_context'])

# Process a query with synonym expansion
def process_query(query, data):
    # Find related terms in the data
    expanded_terms = [query]
    for item in data:
        for term, synonyms in item['related_terms'].items():
            if term.lower() in query.lower():
                expanded_terms.extend(synonyms)
    
    # Create a combined query
    expanded_query = ' '.join(set(expanded_terms))
    return expanded_query
```

## License
This data is provided for use with the Danang Venture and Angel Summit 2025 event.
